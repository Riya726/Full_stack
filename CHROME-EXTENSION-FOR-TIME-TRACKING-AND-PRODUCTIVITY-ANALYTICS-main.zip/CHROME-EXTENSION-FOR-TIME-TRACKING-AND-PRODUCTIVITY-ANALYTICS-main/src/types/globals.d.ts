// Global vars
declare var __EXTENSION_MODE__: ExtensionMode;
declare var __DEV__: boolean;
declare var __PROD__: boolean;
declare var __APP_ID__: string;
declare var __BROWSER__: string;
