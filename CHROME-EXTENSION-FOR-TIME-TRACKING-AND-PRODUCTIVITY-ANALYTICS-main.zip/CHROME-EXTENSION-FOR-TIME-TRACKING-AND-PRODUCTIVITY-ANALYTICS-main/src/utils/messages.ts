export enum Messages {
  RescheduleJobs = 'reschedule-jobs',
  ClearAllData = 'clear-data',
  Restore = 'restore-data',
  PlayAudio = 'play-audio',
}
