export const CHROME_STORE_REVIEW_URL = `https://chromewebstore.google.com/detail/web-activity-time-tracker/${__APP_ID__}/reviews`;
export const CHROME_STORE_SUPPORT_URL = `https://chromewebstore.google.com/detail/web-activity-time-tracker/${__APP_ID__}/support`;
export const CHROME_STORE_CLEAR_YOUTUBE_URL =
  'https://chromewebstore.google.com/detail/clean-youtube-update-yout/kalhfjomailhflienkfajocjodgjipie?utm_source=watt';

export const EDGE_STORE_REVIEW_URL = `https://microsoftedge.microsoft.com/addons/detail/web-activity-time-tracker/${__APP_ID__}#review-section`;
