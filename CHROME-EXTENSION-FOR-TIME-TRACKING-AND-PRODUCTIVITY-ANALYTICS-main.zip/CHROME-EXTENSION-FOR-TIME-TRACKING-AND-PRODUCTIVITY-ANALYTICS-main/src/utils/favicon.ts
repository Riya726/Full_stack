export function getFavicon(url: string) {
  return `https://www.google.com/s2/favicons?domain=${url}&sz=64`;
}
